
for (let i=0; i<=9; i++){

    const el = document.createElement("div");
    el.className = "divN"
    el.id = "Digit" + i;
    el.innerText = "DIV" + i;
    document.body.appendChild(el)
}




function funcY(e){
    try{
        let tasta= document.getElementById(e.code);
    tasta.style.background = "yellow";}
    catch(e){return;}
}


function funcB(e){
    try{
        let tasta= document.getElementById(e.code);
        tasta.style.background = "lightblue";
    
    }

    catch(e){ return;}
}

document.addEventListener('keydown', funcY);
document.addEventListener('keyup', funcB);

