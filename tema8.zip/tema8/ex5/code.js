function moveup(){
    patrat = document.getElementById("piesa")
    if ((parseInt(patrat.style.top)||0)-50<0)
        patrat.style.top="0px"
    else
         patrat.style.top = (parseInt(patrat.style.top)||0)-50+'px';
    }


function moveleft(){
    patrat = document.getElementById("piesa")
    if ((parseInt(patrat.style.left)||0)-50<0)
        patrat.style.left="0px"
    else
        patrat.style.left = (parseInt(patrat.style.left)||0)-50+'px';
}

function movedown(){
    patrat = document.getElementById("piesa")
    if ((parseInt(patrat.style.top)||0)+50>280)
    patrat.style.top="280px"
else
     patrat.style.top = (parseInt(patrat.style.top)||0)+50+'px';
}

function moveright(){
    patrat = document.getElementById("piesa")
    if ((parseInt(patrat.style.left)||0)+50>280)
        patrat.style.left="280px"
    else
        patrat.style.left = (parseInt(patrat.style.left)||0)+50+'px';
}

document.addEventListener('keydown', playGame);

function playGame(e){
    let tasta = e.code
    //if (tasta == "KeyW")
        // alert(tasta)
    if (tasta == "KeyW" || tasta == "ArrowUp")
        moveup();
    else if (tasta == "KeyS" || tasta == "ArrowDown")
        movedown();
    
        else if (tasta == "KeyA" || tasta == "ArrowLeft")
        moveleft();
        
            else if (tasta == "KeyD" || tasta == "ArrowRight")
                moveright();

}