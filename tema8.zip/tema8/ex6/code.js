document.addEventListener("click", addButton)

let i=1;

function addButton(e){
    //alert(e.pageX + " " + e.pageY)
    let btn = document.createElement("button");
    btn.innerHTML = i.toString();
    i+=1;
    btn.style.position = "absolute";
    btn.style.top = e.pageY.toString()+"px";
    btn.style.left = e.pageX.toString()+"px";
    setTimeout(() => {
        btn.style.display = 'none';
    }, 5000);
    document.body.appendChild(btn);

}